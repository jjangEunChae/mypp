package com.example.project.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.project.service.PaymentService;

import com.example.project.vo.PaymentVO;

@Controller
public class PaymentController {
	
	@Inject
	private PaymentService paymentService;
	
	@RequestMapping("/payment/payment")
		public ModelAndView payment(int bno, HttpSession session,
				@RequestParam(defaultValue="") String tourCategory,
				@RequestParam(defaultValue="") String title) {
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("dto", paymentService.read(bno));
		mav.addObject("tourCategory",tourCategory);
		mav.addObject("title",title);
		mav.setViewName("payment/payment");
		
		return mav;
	}
		
	@RequestMapping("/payment/paymentCheck")
	public ModelAndView paymentCheck(@ModelAttribute PaymentVO vo,HttpSession session) {
		//boolean result = paymentService.paymentCheck(vo, session);
		int result = paymentService.insertpayment(vo);
		
		ModelAndView mav = new ModelAndView();
		System.out.println("111");
		if(result ==1) {
			System.out.println("222");
			mav.addObject("msg","결제성공");
			mav.setViewName("/payment/paid");
		}else {
			System.out.println("333");
			mav.addObject("msg","결제실패");
			mav.setViewName("/payment/payment");
		}
		System.out.println("444");
		return mav;
	}

}
